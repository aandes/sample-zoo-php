/* (simply delete this line to activate)

// The methods below illustrate to how augment the mirror's 
// translator scripting API (descriptor, javascript, dash etc).
//
// Only use core JavaScript 3.1 API and, when a DOM element
// is passed, only assert that DOM API level 1 methods of that
// element are available. Also, ensure that the methods are
// stateless. Data will not persist from one call to the next.
// 
// This is to ensure maximum portability of the code as it may,
// in some instances, be ran in a server instead of a browser.

install({ javascript: {
    
    greet: function greet (name) {
    
    	return 'Hello ' + (name || 'world') + '!';
    
    },

    trim: function trim (value) {
    
    	return this.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
        
    }
    
}});
/**/